/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import vista.interfaz_explorador;
/**
 *
 * @author eldai
 */
public class funciones {
    
    static DefaultTableModel modelo2  = (DefaultTableModel) interfaz_explorador.tablaCarpeta.getModel();
    static TableRowSorter<TableModel> modeloFiltrado = new TableRowSorter<TableModel>(modelo2);
    
    private interfaz_explorador view;
    
    
     public static ArrayList<carpeta> lista = new ArrayList();

    public static void rellenar(String direccion) {
        try{
            interfaz_explorador.btnFiltrar.setEnabled(true);
            lista.clear();
            modeloFiltrado.setRowFilter(RowFilter.regexFilter("", 1));
            File f = new File (direccion);
            File [] f1 = f.listFiles();
                for (int i = 0; i < f1.length; i++){
                    //sacamos la extension del fichero
                    String nombreArchivo = f1[i].getName();
                    String nA = "";
                    int x = nombreArchivo.lastIndexOf('.');
                    if (x > 0){
                        nA = nombreArchivo.substring(x+1);
                    }

                    //diferenciamos entre directorio y fichero
                    if (f1[i].isDirectory()){
                        String FicDir = "Es un directorio";
                        String tamaño = f1[i].length()+"";
                        carpeta carpeta = new carpeta(f1[i].getName(),nA,tamaño,FicDir);
                        lista.add(carpeta);
                    }else{
                        String FicDir = "Es un fichero";
                        String tamaño = f1[i].length()+"";
                        carpeta carpeta = new carpeta(f1[i].getName(),nA,tamaño,FicDir);
                        lista.add(carpeta);
                    }  
                }
                enseñar();
                interfaz_explorador.jLabelWarning.setText("");
        }catch(NullPointerException ex){
            interfaz_explorador.jLabelWarning.setText("La ruta introducida no existe");
            interfaz_explorador.btnFiltrar.setEnabled(false);
        }
    }

    public static void filtrar(String filtro) {
            interfaz_explorador.tablaCarpeta.setRowSorter(modeloFiltrado);
            modeloFiltrado.setRowFilter(RowFilter.regexFilter(filtro,1));
    }

    private static void enseñar() {
        String matriz [][] = new String[lista.size()][4];
        
        for (int x = 0; x < lista.size(); x++){
            matriz[x][0] = lista.get(x).getNombre();
            matriz[x][1] = lista.get(x).getExtension();
            matriz[x][2] = lista.get(x).getTamaño();
            matriz[x][3] = lista.get(x).getFicDir();
        }
        
        interfaz_explorador.tablaCarpeta.setModel(new javax.swing.table.DefaultTableModel(
                matriz,
                new String[] {
                    "Nombre", "Extension", "Tamaño", "D/F"
                }
        ));
    }
}
