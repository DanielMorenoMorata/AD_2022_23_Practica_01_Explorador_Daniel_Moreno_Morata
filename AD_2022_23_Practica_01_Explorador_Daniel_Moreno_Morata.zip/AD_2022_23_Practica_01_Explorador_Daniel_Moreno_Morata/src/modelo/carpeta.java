/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author eldai
 */
public class carpeta implements Serializable{
    
    //declaramos
    
    private String Nombre, Extension, Tamaño, FicDir;
    
    public carpeta (String Nombre, String Extension, String Tamaño, String FicDir){
        this.Nombre = Nombre;
        this.Extension = Extension;
        this.Tamaño = Tamaño;
        this.FicDir = FicDir;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getExtension() {
        return Extension;
    }

    public void setExtension(String Extension) {
        this.Extension = Extension;
    }

    public String getTamaño() {
        return Tamaño;
    }

    public void setTamaño(String Tamaño) {
        this.Tamaño = Tamaño;
    }

    public String getFicDir() {
        return FicDir;
    }

    public void setFicDir(String FicDir) {
        this.FicDir = FicDir;
    }
    
    
    
}
